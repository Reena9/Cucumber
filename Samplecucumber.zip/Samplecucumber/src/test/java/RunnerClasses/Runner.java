package RunnerClasses;

import java.text.SimpleDateFormat;
import java.util.Date;


import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.testng.AbstractTestNGCucumberTests;



@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/test/resources", // Correct path to your feature files
        //tags= "@test",
        glue = {"StepsDefinations", "Utils"}, // Correct package name where your step definitions are located
        plugin = {"pretty", "html:target/cucumber-reports", "json:target/cucumber.json","junit:target/cucumber.xml", "rerun:target/rerun.txt"}
        //monochrome = true
)


public class Runner extends AbstractTestNGCucumberTests {
	
	  private static WebDriver driver;
	  
	  @BeforeClass public static void beforeclass() { SimpleDateFormat
	  dateformat=new SimpleDateFormat("dd-mm-yyyy hh-mm-ss");
	  System.setProperty("currentdate",dateformat.format(new Date()));
	  //SeleniumUtil.cleanFolder("Logs");
	  
	  
	  }
	  
	  @AfterClass public static void afterclass() {
	  
	  driver.close();
	  
	  
	  }
	 
	
}
