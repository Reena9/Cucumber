package StepsDefinations;

import java.time.Duration;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;



public class DealPage {
	
	//private WebDriver driver;
	private WebDriver driver = Hooks.getDriver();
	
	@Given("User on Offercenter page")
	public void user_on_offercenter_page() throws InterruptedException {

		WebDriverWait wait1 = new WebDriverWait(driver,Duration.ofSeconds(20)); // Timeout in seconds
	      wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()=\"Deals\"]"))).click();
		
		
	}

	@When("User clear the filters by selecting none")
	public void user_clear_the_filters_by_selecting_none() throws InterruptedException {
	   driver.findElement(By.id("ddlDealStatus")).click();
	   driver.findElement(By.xpath((".//li[@data-value='None']"))).click();
	  
	}

	@When("User selects all")
	public void user_selects_all() throws InterruptedException {
		 driver.findElement(By.xpath((".//li[@data-value='All']"))).click();
		  
	  
	}

	@When("Click on find button")
	public void click_on_find_button() throws InterruptedException {
		
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
		  wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnFSecFind"))).click();
        

    }
	    

	@Then("all deals should be appear")
	public void all_deals_should_be_appear() {
		
	   System.out.println("All deals are appearing");
	}}