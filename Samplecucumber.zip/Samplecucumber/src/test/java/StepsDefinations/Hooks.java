
	package StepsDefinations;

	import java.io.File;
	import java.nio.file.Files;
	import java.nio.file.Paths;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
	import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.After;
	import io.cucumber.java.Before;
	import io.cucumber.java.Scenario;

	public class Hooks {
		public static WebDriver driver;
		private static final String SCREENSHOT_PATH = "screenshots/";
		
		
		
		
		@Before
	    public void setupDriver() {
			  if (driver == null) {
		            System.setProperty("webdriver.chrome.driver", "C:\\Users\\ReenaDahiya\\Samplecucumber\\Drivers\\chromedriver.exe");
		            driver = new ChromeDriver();
		            driver.manage().window().maximize();
		      	  driver.get("https://qa01.demandtec.com/");
		      	  driver.findElement(By.id("username")).sendKeys("rleever");
		    	  driver.findElement(By.id("password")).sendKeys("Welcome@Sep2023");
		    	  driver.findElement(By.xpath("//button[@type='submit']")).click();
		    	
		    	  WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20)); // Timeout in seconds
		       wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("sub-li-dealmanagement"))).click();
		    
			System.out.println("Before");
		}
		}
		 public static WebDriver getDriver() 
	        { 
	        	return driver; 
	        	}
		
		 @After
		    public void embedScreenshot(Scenario scenario) {
		        if (scenario.isFailed()) {
		        try {	
		           TakesScreenshot ts=(TakesScreenshot)driver;
		           byte[] screenshot = ts.getScreenshotAs(OutputType.BYTES);
		          
		                String screenshotName = scenario.getName().replaceAll(" ", "_");
		                String screenshotFilePath = SCREENSHOT_PATH + screenshotName + ".png";
		                scenario.attach(screenshot, "image/png", screenshotName);
		                // Check if screenshot file exists
		                File screenshotFile = new File(screenshotFilePath);
		              
	}     
    catch (Exception e) {
        System.out.println("Exception while taking screenshot: " + e.getMessage());
    } 
		        if (driver != null) {
		            driver.quit();
		            driver = null;
		     
		        }}
		        
		       
	}}

	