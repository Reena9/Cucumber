package StepsDefinations;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import Utils.ExtentReportUtil;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Login{
	//private WebDriver driver;
	private WebDriver driver = Hooks.getDriver();
	 
	@Given("User Hit URL of page")
	 public void user_hit_url_of_page() {
			/*
			 * System.setProperty("webdriver.chrome.driver",
			 * "C:\\Users\\ReenaDahiya\\Samplecucumber\\Drivers\\chromedriver.exe");
			 * driver=new ChromeDriver();
			 */
		 System.out.println("User login");
	        ExtentReportUtil.log("URL Hit");
	        
	     
	 }

	 @When("user enter username {string}")
	 public void user_enter_username(String username) {
		 driver.findElement(By.id("username")).sendKeys(username);
		 ExtentReportUtil.log("username entered");
		 
	 }

	 @When("user enter password {string}")
	 public void user_enter_password(String password) {
		 driver.findElement(By.id("password")).sendKeys(password);
		 ExtentReportUtil.log("password entered");
		
	 }

	 @When("user click on login page")
	 public void user_click_on_login_page() throws InterruptedException {
		 driver.findElement(By.xpath("//button[@type='submit']")).click();
		Thread.sleep(3000);
		 ExtentReportUtil.log("Login button clicked");
	 }

	 @Then("User should be able to login and navigate on homepage")
	 public void user_should_be_able_to_login_and_navigate_on_homepage() {
		 ExtentReportUtil.log("Login success");

	 }


	 @When("User click on offer center")
	 public void user_click_on_offer_center() {
	     driver.findElement(By.id("sub-li-dealmanagement")).click();
	     ExtentReportUtil.log("Offer center clicked");
	     
	 }

	 @Then("User should be navigate on deal page")
	 public void user_should_be_navigate_on_deal_page() {
		 ExtentReportUtil.log("Deal page opened");
	    
}
	 

}
