package StepsDefinations;


import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class costchange {
	//private WebDriver driver;
	
	private WebDriver driver = Hooks.getDriver();
  @Given("User clicks on cost change menu")
  
public void user_clicks_on_cost_change_menu() {
	  WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(30));
	  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//*[@ng-bind='menu1.Title'])[2]"))).click();
	
  }
     

@When("user clicks on approved cc")
public void user_clicks_on_approved_cc(){
	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20)); // Timeout in seconds
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Approved']"))).click();
  
}

@Then("Fetch total count")
public void fetch_total_count() {
	String count=driver.findElement(By.cssSelector("div[title='Approved'] div[class='title']")).getText();
	System.out.println(count);
}

/*
 * @Given("User clicks on offer center") public void
 * user_clicks_on_offer_center() throws InterruptedException {
 * driver.findElement(By.xpath("//span[text()=\"Deals\"]")).click();
 * driver.wait(2000); }
 * 
 * @When("user clicks on new") public void user_clicks_on_new() throws
 * InterruptedException { driver.findElement((By.id("bBatchAction"))).click();
 * driver.wait(3000);
 * driver.findElement(By.id("ToolbarVendorPartyForeignKey_lnkChoose")).click();
 * }
 * 
 * @Then("new form open") public void new_form_open() {
 * System.out.println("New form open for selection of vendor"); }
 */
}
