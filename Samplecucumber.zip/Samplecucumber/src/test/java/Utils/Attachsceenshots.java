package Utils;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;

import io.cucumber.java.After;
import io.cucumber.java.Scenario;

public class Attachsceenshots {
	private static final String SCREENSHOT_PATH = "screenshots/";

    @After
    public void embedScreenshot(Scenario scenario) {
        if (scenario.isFailed()) {
            try {
                // Get screenshot file path
                String screenshotName = scenario.getName().replaceAll(" ", "_");
                String screenshotFilePath = SCREENSHOT_PATH + screenshotName + ".png";

                // Check if screenshot file exists
                File screenshotFile = new File(screenshotFilePath);
                if (screenshotFile.exists()) {
                    byte[] screenshotBytes = Files.readAllBytes(Paths.get(screenshotFilePath));
                    scenario.attach(screenshotBytes, "image/png", screenshotName);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    
    
    
    
}

