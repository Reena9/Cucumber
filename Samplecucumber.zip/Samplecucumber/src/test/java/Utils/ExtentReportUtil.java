package Utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.Status.*;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.IOException;
import java.util.Base64;

public class ExtentReportUtil {
    private static ExtentReports extent;
    private static ExtentTest scenario;
    private static WebDriver driver;

    public static void initialize() {
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("extent.html");
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
    }

    public static void setScenario(Scenario cucumberScenario) {
        scenario = extent.createTest(cucumberScenario.getName());
    }

    public static void setDriver(WebDriver driver) {
        ExtentReportUtil.driver = driver;
    }

    @Before
    public void setUp(Scenario scenario) {
        initialize(); // Initialize extent reports
        setScenario(scenario); // Set scenario
    }

    @After
    public void tearDown(Scenario scenario) {
        if (scenario.isFailed() && driver != null) {
            captureScreenshot(scenario.getName()); // Capture screenshot for failed scenarios
        }
        log("Test execution completed for scenario: " + scenario.getName());
        extent.flush(); // Flush extent reports
    }

    public static void log(String log) {
        if (scenario != null) {
            scenario.log(Status.INFO, log);
        } else {
            System.out.println("Scenario is null. Cannot log.");
        }
    }

    public static void captureScreenshot(String screenshotName) {
        try {
            if (driver != null) {
                byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
                scenario.fail("Test Case Failed - " + screenshotName,
                        MediaEntityBuilder.createScreenCaptureFromBase64String(Base64.getEncoder().encodeToString(screenshot)).build());
            } else {
                System.out.println("Driver is null. Cannot capture screenshot.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void logStep(Status status, String stepName) {
        if (scenario != null) {
            switch (status) {
                case PASS:
                    scenario.pass(stepName);
                    break;
                case FAIL:
                    scenario.fail(stepName);
                    break;
                case SKIP:
                    scenario.skip(stepName);
                    break;
                default:
                    scenario.log(Status.INFO, stepName);
                    break;
            }
        } else {
            System.out.println("Scenario is null. Cannot log step.");
        }
    }
}
