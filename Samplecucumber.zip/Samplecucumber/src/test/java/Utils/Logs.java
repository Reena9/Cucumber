package Utils;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Logs {
	


	    private static final String LOG_FILE_PATH = "logs/test.log";

	    public static void log(String message) {
	        try {
	            File logFile = new File(LOG_FILE_PATH);
	            if (!logFile.exists()) {
	                logFile.getParentFile().mkdirs();
	                logFile.createNewFile();
	            }

	            FileWriter writer = new FileWriter(logFile, true);
	            String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
	            writer.write("[" + timestamp + "] " + message + "\n");
	            writer.close();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	}



