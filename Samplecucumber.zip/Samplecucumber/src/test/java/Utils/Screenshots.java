package Utils;

public class Screenshots {

}
