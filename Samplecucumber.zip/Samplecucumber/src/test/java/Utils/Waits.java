package Utils;

public class Waits {

}
